import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Task } from '../task';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {

  @Input()
  task: Task = new Task();

  @Output()
  add: EventEmitter<Task>=new EventEmitter();


  addTask() {
    this.add.emit(this.task);
    console.log("Task added"+ this.task.taskName);
    this.task=new Task();

  }

  constructor() { }

  ngOnInit() {
  }

}
