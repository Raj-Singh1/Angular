export class Task {
    // taskId: number;
    id:number;
    taskName: string;
    complete: boolean = false;
}
