import { Component, OnInit, Output } from '@angular/core';
import { Task } from '../task';
import { TodoService } from '../todo.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css'],
  providers: [TodoService]
})

export class TaskComponent implements OnInit {

  tasks: Task[] = [];
//  task: Task = new Task();
  constructor(private todoserivice : TodoService) { }

  ngOnInit() {
    this.todoserivice.getallTask().subscribe((taskData)=>this.tasks=taskData);
  }

  addTask(task): void {
    console.log(JSON.stringify(this.tasks));
    if(!task.id)
    {
      this.todoserivice.addTask(task).subscribe((taskData)=>{this.todoserivice.getallTask().subscribe((taskData)=>this.tasks=taskData);})
      //this.tasks= (when we donot use subscribe normal implementation)
 //     this.todoserivice.getallTask().subscribe((taskData)=>this.tasks=taskData);
    }
    else{
      this.todoserivice.updateTask(task).subscribe((taskData)=>{this.todoserivice.getallTask().subscribe((taskData)=>this.tasks=taskData);});
      //this.tasks=this.todoserivice.getallTask();
      //this.todoserivice.getallTask().subscribe((taskData)=>this.tasks=taskData);
    }
      task = new Task();
      console.log(JSON.stringify(this.tasks));
  }

  removeTask(id : number) : void{
    this.todoserivice.removeTask(id).subscribe((taskData)=>{this.todoserivice.getallTask().subscribe((taskData)=>this.tasks=taskData);},(error)=>{
      console.log('error ocurred');
    });
    // console.log("delete"+id);
    // this.todoserivice.removeTask(id);
    // // this.tasks=this.todoserivice.getallTask();
  }

  updateTask(t: Task): void{
    console.log("update");
    Object.assign(this.task,t);
  }
}