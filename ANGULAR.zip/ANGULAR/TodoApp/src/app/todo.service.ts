import { Injectable, Output } from '@angular/core';
import { Task } from './task';
import { Http,Response } from '@angular/http'
import { Observable } from '../../node_modules/rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class TodoService {
  counter : number = 0;
  task :Task[]=[];

  constructor(private http: Http) { }

addTask(task : Task) : Observable<Task[]>{
  // if(!t.taskId)
//   if(!task.id)
//   {
//     task.id=++this.counter;
// //    t.taskId=++this.counter;
//   }
//   console.log(JSON.stringify(this.task));
//   console.log(JSON.stringify(task));
//   this.task.push(task);
console.log(JSON.stringify(this.task));
  return this.http.post("http://localhost:3000/Tasks",task).map((response:Response)=><Task[]>response.json());
}

getallTask() : Observable<Task[]> {//Task[]{
  return this.http.get("http://localhost:3000/Tasks").map((response:Response)=><Task[]>response.json());
  
  //return this.task;
}

removeTask(id : number): Observable<Task[]>{
 
  return this.http.delete("http://localhost:3000/Tasks/"+id).map((response:Response)=><Task[]>response.json()).catch(this.handleError);
  //return null;
}
 handleError(error :Response)
{
  console.log(error);
  return Observable.throw(error);
}

updateTask(tasks) : Observable<Task[]>{
  //this.removeTask(task.taskId);
  // this.removeTask(tasks.id);
  // this.addTask(tasks);
  return this.http.put(("http://localhost:3000/Tasks/"+tasks.id),tasks).map((response:Response)=><Task[]>response.json()).catch(this.handleError);
}
}
