export class Product {
    proId : number;
    proName : string;
    proQuantity : number;
    
}
