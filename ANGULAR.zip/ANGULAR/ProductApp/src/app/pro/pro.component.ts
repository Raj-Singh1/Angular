import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProdService } from '../prod.service';

@Component({
  selector: 'app-pro',
  templateUrl: './pro.component.html',
  styleUrls: ['./pro.component.css'],
  providers: [ProdService]
})
export class ProComponent implements OnInit {
  prod : Product[] = [];
pro : Product = new Product();
  constructor() { }

  ngOnInit() {
  }

  addPro()
  {
    console.log(JSON.stringify(this.pro));
    this.pro=new Product();
  }

}
