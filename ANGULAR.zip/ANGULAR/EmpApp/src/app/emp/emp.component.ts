import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css'],
  providers: [EmployeeService]
})
export class EmpComponent implements OnInit {
  emp: Emp = new Emp();
emps : Emp[] = [];
  constructor(private employeeService: EmployeeService) { }

  ngOnInit() {
  }

  addEmp():void {
    console.log(JSON.stringify(this.emp));
   if(!this.emp.id)  
   {
     this.employeeService.addEmployee(this.emp).subscribe((EmpData)=>{this.employeeService.getAllEmployees().subscribe((EmpData)=>this.emps=EmpData);});
    //  this.employeeService.getAllEmployees().subscribe((EmpData)=>this.emps=EmpData);
  //  {
  //  this.employeeService.addEmployee(this.emp);
  //  //this.emps=this.employeeService.getAllEmployees();
  }
  else
  {
    this.employeeService.updateEmp(this.emp).subscribe((EmpData)=>{ this.employeeService.getAllEmployees().subscribe((EmpData)=>this.emps=EmpData);})
   // this.emps = this.employeeService.getAllEmployees();
  }
 // this.employeeService.getAllEmployees().subscribe((EmpData)=>this.emps=EmpData);
  this.emp = new Emp();
  console.log(JSON.stringify(this.emps));
  }

  removeEmp(id : number) {
//    this.emps=this.employeeService.getAllEmployees();
//this.employeeService.getAllEmployees().subscribe((EmpData)=>this.emps=EmpData);
this.employeeService.removeEmp(id).subscribe((EmpData)=>{this.employeeService.getAllEmployees().subscribe((EmpData)=>this.emps=EmpData);},(error)=>
{
  console.log('error ocurred');
  });  
}
  
  updateEmp(e : Emp)
  {
    console.log('clicked');
    Object.assign(this.emp,e);
  }
}
