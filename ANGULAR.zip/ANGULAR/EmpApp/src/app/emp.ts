export class Emp {
    id : number;
    empName: string;
    empSalary: number;
    empDob: string;
}
