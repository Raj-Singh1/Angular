import { Injectable } from '@angular/core';
import { Emp } from './emp';
import { Http,Response } from '@angular/http';
import { Observable } from '../../node_modules/rxjs/Observable';
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";

@Injectable()
export class EmployeeService {

  counter: number = 0;
  employees: Emp[] = [];

  constructor( private http : Http) { }

  addEmployee(emp: Emp): Observable<Emp[]> {

    // if (!emp.empId) {
    //   emp.empId = ++this.counter;
    // }
    // this.employees.push(emp);
    // console.log(JSON.stringify(this.employees));
    return this.http.post("http://localhost:3000/Employee",emp).map((response:Response)=><Emp[]>response.json());
    
   // return this;
  }

  getAllEmployees(): Observable<Emp[]> {
    return this.http.get("http://localhost:3000/Employee").map((response:Response)=><Emp[]>response.json());
  }

  removeEmp(id: number): Observable<Emp[]>{//EmployeeService {
    // this.employees = this.employees.filter(x => x.id != id);
    // return this;
    return this.http.delete("http://localhost:3000/Employee/"+id).map((response:Response)=><Emp[]>response.json()).catch(this.handleError);
    //return null;
  }
   handleError(error :Response)
  {
    console.log(error);
    return Observable.throw(error);
  }


  updateEmp(e) : Observable<Emp[]>{
    //this.removeEmp(emp.empId);
    // this.addEmployee(emp);
    // this.removeEmp(emp.id);
    // this.employees.push(emp);
    return this.http.put(("http://localhost:3000/Employee/"+e.id),e).map((response:Response)=><Emp[]>response.json()).catch(this.handleError);
  }

}