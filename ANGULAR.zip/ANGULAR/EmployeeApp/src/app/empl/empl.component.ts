import { Component} from '@angular/core';

@Component({
  selector: 'app-empl',
  templateUrl: './empl.component.html',
  styleUrls: ['./empl.component.css']
})
export class EmplComponent {

  status : boolean=false;
  data : number =0;

  show():void{
    this.status=!this.status;
  }

  doget() : void{
    this.data=0;
  }

  doget1() : void {
    this.data=1;
  }
   
  doget2() : void{
    this.data=2;
  }
}
