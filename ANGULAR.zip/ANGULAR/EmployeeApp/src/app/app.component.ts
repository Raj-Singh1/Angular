import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  employess : Employee[] = [
    {empId:1001,empName:'Sinha Ji',empSalary:15500,empDep:'JAVA',empjoiningdate:'19/09/2018'},
    {empId:1002,empName:'Shah Ji',empSalary:15500,empDep:'JAVA',empjoiningdate:'19/09/2018'},
    {empId:1003,empName:'Sharma Ji',empSalary:15500,empDep:'JAVA',empjoiningdate:'19/09/2018'},
    {empId:1004,empName:'Yadav Ji',empSalary:15500,empDep:'JAVA',empjoiningdate:'19/09/2018'},
    {empId:1005,empName:'Barde Ji',empSalary:15500,empDep:'JAVA',empjoiningdate:'19/09/2018'},
    {empId:1006,empName:'Baseer Ji',empSalary:15500,empDep:'JAVA',empjoiningdate:'19/09/2018'}
  ]
}
