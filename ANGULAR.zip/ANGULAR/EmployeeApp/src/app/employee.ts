export class Employee {
    empId : number;
    empName : string;
    empSalary : number;
    empDep : string;
    empjoiningdate : string;
}
