import { Injectable } from "../../node_modules/@angular/core";
import { Mobile } from "./app.mobile";

@Injectable({
    providedIn: "root"
})
export class MobileService {


    mobileData:Mobile[] = [];

    addData(mobtemp:Mobile) : boolean{
        this.mobileData.push(mobtemp);
        return true;
    }

    showAllData() : Mobile[] {
        console.log(this.mobileData);
        return this.mobileData;
    }

    showSearchedData(searchId) : Mobile[] {

        let mobTemp:Mobile[] = [];
        for(let data of this.mobileData) {
            if(data.mobId == searchId)
            {
                mobTemp.push(data);
            }
        }
        return mobTemp;
    }

    delete(searchId) : Mobile[] {

        let mobTemp:Mobile[] = [];
        let i =0;
        for(let data of this.mobileData) {
            if(data.mobId == searchId)
            {
                this.mobileData.splice(i,1);
            }
            i++;
        }
        return this.mobileData;
    }

}