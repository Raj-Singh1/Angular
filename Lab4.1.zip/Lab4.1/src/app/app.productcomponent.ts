

import { Component, OnInit } from "../../node_modules/@angular/core";
import {Productservice} from './app.productservice';
import {Product} from './product';
@Component({
    selector:'prod-app',
    templateUrl:'./app.product.html',
    providers:[Productservice]
})
export class ProductComponent implements OnInit{
products:Product[];
constructor(private _productservice:Productservice)
{

}

ngOnInit()
{
this._productservice.getAllProduct().subscribe((data:Product[])=>this.products=data);
}
delete(i:number):any{
    return this.products.splice(i,1);
}
}