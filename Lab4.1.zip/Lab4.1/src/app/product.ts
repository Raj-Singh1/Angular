


export class Product{
    id:number;
    title:string;
    year:number;
    author:string
}