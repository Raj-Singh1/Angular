import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "../../node_modules/@angular/router";
import { MobileService } from "./appcomponentservice";
import { Mobile } from "./app.mobile";


@Component(
    {
        selector: "mob-show",
        templateUrl: "./app.showmobiles.html"
        
    }
)
export class ShowSearchMobile implements OnInit {

    mobId:number;
    constructor(
        private route:ActivatedRoute,
        private mobileService: MobileService
    ){}

    empArr:Mobile[];
    msg:string;

    ngOnInit(): void {
        this.mobId = this.route.snapshot.params["id"];

        this.empArr = this.mobileService.showSearchedData(this.mobId);

        
        if(this.empArr.length == 0){
            this.msg = "No Employee Found";
        }
    }
}