import { Component } from "@angular/core";
import { Router } from '@angular/router';


@Component(
    {
        selector: "mob-search",
        templateUrl: "./app.searchmobile.html"
    }
)
export class SearchMobileComponent {
    
    constructor(private router: Router){}

    mobId:number;
    

    show(){
        this.router.navigate([`showsearchmobile/${this.mobId}`]);
    }

}