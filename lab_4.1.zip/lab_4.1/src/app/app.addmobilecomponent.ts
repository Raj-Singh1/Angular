import { Component } from "@angular/core";
import { MobileService } from "./appcomponentservice";
import { Router } from "../../node_modules/@angular/router";



@Component(
    {
        selector: "mob-add",
        templateUrl: "./app.addmobile.html"
    }
)
export class AddMobileComponent {

    ID:number = null;
    Name:string= "";
    Price:number= null;
    Brand:string= "";
    
    mobTemp:any={};


    constructor(private mobileService: MobileService, private router: Router){
  
    }

    addData(){

        this.mobTemp = {
            mobId:this.ID,
            mobName:this.Name,
            mobPrice:this.Price,
            mobBrand:this.Brand
        }
        

        if(this.mobileService.addData(this.mobTemp)) 
        {
            this.router.navigate(['show']);
        }

          this.ID = null;
          this.Name = "";
          this.Price = null;
          this.Brand = "";
        
    
        
      }
}