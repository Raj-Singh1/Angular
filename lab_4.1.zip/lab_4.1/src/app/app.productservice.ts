import { Injectable } from "../../node_modules/@angular/core";
import { HttpClient } from '@angular/common/http'
@Injectable()
export class Productservice{
constructor(private http:HttpClient){}
getAllProduct():any{
  return  this.http.get("assets/product.json");
}

}