import React, { Component } from 'react';
import './App.css';


var createClass=require('create-react-class');
var App=createClass(
  {
    render:function()
    {
      const Welcome=React.createElement('h1',null,'welcome to capgemini');
      return <div>{Welcome}</div>;
    }
  }
);

export default App;
