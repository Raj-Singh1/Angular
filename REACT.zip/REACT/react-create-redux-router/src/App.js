import React from 'react';

import ReactDOM from 'react-dom';

import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom'
import { Link, Switch } from 'react-router-dom';

/*4.x introduced some breaking changes, you'll need to import Link from react-router-dom:*/

const Home = () => (<div><h1>Welcome home</h1>
  <Link to='/about'>Go to about</Link><br />
  <Link to='/users'>Go to user</Link></div>)
const About = ({ name }) => (<div><h1>About {name}</h1></div>)
const Users = () => (<div><h1>HEllo</h1></div>)

class App extends React.Component {
  render() {
    return (
      <Router>
        <Switch>

          <Route
            path="/users"
            render={(renderProps) => (
              <div>
                <Users {...this.props} {...renderProps} />
                <Link to='/'>Go home</Link>
              </div>
            )} />

          <Route
            path="/about"
            render={(renderProps) => (
              <div>
                <Link to='/about/java'>Java</Link><br />
                <Link to='/about/dotnet'>Dot Net</Link>
                <Route
                  path="/about/:name"
                  render={(renderProps) => (
                    <div>
                      <About name={renderProps.match.params.name} />
                      <Link to='/'>Go home</Link>
                    </div>
                  )} />
              </div>
            )} />

          <Route
            path="/"
            render={(renderProps) => (
              <div>
                Home is underneath me
                <Home {...this.props} {...renderProps} />
              </div>
            )} />
        </Switch>
      </Router>
    )
  }
}
export default App;


