import React from 'react';

class FormEg extends React.Component{
    constructor()
    {
        super();
        this.state={
            firstName : "",
            lastName : "",
            friends : []
        }
    }

    handleSubmit = (event) =>{
        event.preventDefault();
        const friendsArr = this.state.friends.slice();
        console.log(friendsArr);
        friendsArr.push(this.state.firstName);
        friendsArr.push(this.state.lastName);
        this.setState(
            {
                friends : friendsArr,
                firstName : '',
                lastName : ''
            }
        );
        setTimeout(()=>{
            console.log("All friends: ", this.state.friends)
        },500);
        }

    handleChange = (event)=>{
        if(event.target.name == 'fname'){
            this.setState({
                firstName:event.target.value
            });
        }
        else{
            this.setState({
                lastName:event.target.value
            });
        }
    }

render(){
    return(
        <div>
            <h3>Name : {this.state.firstName} {this.state.lastName}</h3>
            <h3>First Name : {this.state.firstName}</h3>
            <h3>Last Name : {this.state.lastName}</h3>
            <form onSubmit={this.handleSubmit}>
                <label>First Name</label>
                <input type="text" value={this.state.firstName} onChange={this.handleChange} name="fname"/>
                <br/>
                <label>Last Name</label>
                <input type="text" value={this.state.lastName} onChange={this.handleChange} name="lname"/>
                <br/>
                <input type="submit" value="Submit" />
            </form>
            <hr/>
            <ul>
                {
                    this.state.friends.map((friend,index)=>{
                        return <li key={index}>{friend}</li>
                    })
                }
            </ul>
        </div>    
    )
}
}

export default FormEg;