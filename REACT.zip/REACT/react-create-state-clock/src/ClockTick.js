import React from 'react';

class ClockTick extends React.Component{
constructor(){
    super();
    this.state={Place : ['IGATE']};  
}
render()
{
setTimeout(()=>{
    const item = this.state.Place;
    item[0]="Capgemini";
    console.log(item);
    this.setState({Place:item});
},1000)
return (
        <span>{this.state.Place}</span>
)
}
}

export default ClockTick;