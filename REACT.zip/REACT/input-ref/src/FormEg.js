import React from 'react';
import ReactDOM from 'react-dom';


class FormEg extends React.Component {
	handleClick = (event) => {
		event.preventDefault();
		console.log(this.refs.username.value);
	}

	render() {
		return (
			<div>
				<label>Name: </label>
				<input type="text" ref="username" name="username" />
				<br />
				<input type="button" value="SAY IT!!" onClick={this.handleClick} />
			</div>
		)
	}
}

export default FormEg;