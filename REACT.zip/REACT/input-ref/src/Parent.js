import React from 'react';
import Child from './Child';

class Parent extends React.Component{
    constructor()
    {
        super();
        this.state={
            companyName : "CG",
            location : "Banglore"
        }
    }

    handleChange=(event)=>{
        this.setState({
            companyName : event.target.value
        });
    }
    
    render()
    {
        return (
            <div>
                {/* HERE CHILD GO AS CHILDREN DAY :- */}
                Company Name from Parent:- 
                <input type="text" value={this.state.companyName} onChange={this.handleChange} />
                <br/>
                <Child companyName ={this.state.companyName} /> 
                </div>
        )
    }
}

export default Parent;