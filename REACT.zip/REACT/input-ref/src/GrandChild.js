import React from 'react';

class GrandChild extends React.Component{
    render()
    {
        return (
            <div>
                Company Name from GrandChild:- {this.props.companyName}
                </div>
        )
    }
}

export default GrandChild;