import React from 'react';
import ReactDOM from 'react-dom';
import Loop from './ForEach';
// import Parent from './Parent';

// class Demo extends React.Component {
//     render() {
//         return (
//             <div>
//                 <Parent >
//                     <br />
//                     <button> register </button>
//                     <br />
//                     this is a sample content
//                 </Parent>
//             </div>
//         );
//     }
// }
// ReactDOM.render(<Demo />, document.getElementById('root'));

ReactDOM.render(<Loop />, document.getElementById('root'));