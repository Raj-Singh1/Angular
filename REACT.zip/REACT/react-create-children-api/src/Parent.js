import React from 'react';
import ReactDOM from 'react-dom';

class Parent extends React.Component {
    render() {
        const co = React.Children.count(this.props.children);
        const buttons = React.Children.map(this.props.children, child => (
            <div>
                <br />
                  {child}
                  
                Type of the element is:{child.type}
                <hr />
            </div>
        ));
        if (co > 1) {
            return (
                <div>
                    count: {React.Children.count(this.props.children)}
                    {buttons}
                 <p>There should be only one child</p> </div>
            );
        }
     else {
           return (
                <div>
                    count: {React.Children.count(this.props.children)}
                    {buttons}
                </div>
            );
        }
    }
}
export default Parent;