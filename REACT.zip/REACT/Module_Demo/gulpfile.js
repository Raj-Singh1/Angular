//npm install -g gulp
//npm install

var gulp = require("gulp");

gulp.task("mytask", function(){
    console.log("My Task successfully");
})

gulp.task("default",["mytask"], function(){
    console.log("GULP setup successfully");
});