import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InnermostComponent } from './innermost.component';

describe('InnermostComponent', () => {
  let component: InnermostComponent;
  let fixture: ComponentFixture<InnermostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InnermostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InnermostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
