import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innermost',
  templateUrl: './innermost.component.html',
  styleUrls: ['./innermost.component.css']
})
export class InnermostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
