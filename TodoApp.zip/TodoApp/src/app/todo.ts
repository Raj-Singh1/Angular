export class Todo {
    taskId : number;
    taskName : string;
    complete : boolean=false;
    constructor(values : Object={})
    {
        (<any>Object).assign(this,values);
    }
}
