export class Login {
    LoginName : string;
    LoginPassword : string;
    complete : boolean=false;
    constructor(values : Object={})
    {
        (<any>Object).assign(this,values);
    }
}
