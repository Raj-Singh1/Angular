import { Component, OnInit } from '@angular/core';
import { Login } from '../login'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  l : Login = new Login(); 

  constructor() {
this.l.LoginName="Not declared";
this.l.LoginPassword="Not mentioned";
 console.log(this.l.LoginName);
 console.log(this.l.LoginPassword);
  }

  ngOnInit() {
  }

}
