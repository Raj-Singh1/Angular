class Employee1 {
    eId: number;
    eName: string;
    eSalary: number;

    constructor(values : Object={})
    { 
        Object.assign(this,values)
        console.log(this.eId + " " + this.eName + " " + this.eSalary)
    }
}

var emp1=new Employee1();
var emp1_1=new Employee1({eid:100,ename:"aj",esalary:15000});


class Product {
    proId: number;
    proName: string;
    constructor(value: Object = {}) {
        (<any>Object).assign(this,value);
        console.log(this.proId);
        console.log(this.proName);
    }
}