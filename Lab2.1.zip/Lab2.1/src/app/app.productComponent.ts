import { Component } from "@angular/core";
import {Product} from './Product';
@Component({
    selector:"prod-app",
    templateUrl:'app.product.html'
})
export class productComponent extends Product{

    model:any={};
    model1:any={};
    arr:Product[]=[
        {prodId:1001,prodName:"A",prodPrice:156},
        {prodId:1002,prodName:"B",prodPrice:158},
        {prodId:1003,prodName:"C",prodPrice:157}
    ];
addDetails():any{
  this.arr.push(this.model);
  this.model={};
}
delete(id):any{
   // alert(id);
    this.arr.splice(id,1);
}
update(id):any{
// this.model1.prodId=this.arr[id].prodId;
// this.model1.prodName=this.arr[id].prodName;
// this.model1.prodPrice=this.arr[id].prodPrice;
this.model1=this.arr[id];
    alert(id);
}
updatepro():any{
   
    this.model1.prodId=(document.getElementById("a") as HTMLInputElement).value;
    this.model1.prodName=(document.getElementById("b") as HTMLInputElement).value;
    this.model1.prodPrice=(document.getElementById("c") as HTMLInputElement).value;
    this.model1={};
  
}
}