import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
//import { productComponent } from './productcomponent';
import { FormsModule} from '@angular/forms'
import { productComponent } from './app.productComponent';

@NgModule({
  declarations: [
    AppComponent,productComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
