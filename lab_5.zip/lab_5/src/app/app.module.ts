import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {RouterModule, Routes} from "@angular/router";
import { ShowMobileComponent } from './app.showmobilecomponent';
import { AddMobileComponent } from './app.addmobilecomponent';
import { SearchMobileComponent } from './app.searchmobilecomponent';
import { ShowSearchMobile } from './app.showSearchMobile';
import { FormsModule} from "@angular/forms";

const routes:Routes = [
  {path: "", redirectTo: "show", pathMatch: "full"},
  {path: "show", component: ShowMobileComponent},
  {path: "add", component: AddMobileComponent},
  {path: "search", component: SearchMobileComponent},
  {path: "showsearchmobile/:id", component: ShowSearchMobile}
];
@NgModule({
  declarations: [
    AppComponent,
    SearchMobileComponent,
    AddMobileComponent,
    ShowMobileComponent,
    ShowSearchMobile
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
