// import { Component } from "../../node_modules/@angular/core";
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: "./app.component.html"

  // templateUrl: './app.component.html',
  // styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string = 'From Parrent using Input';
  // welcome:string = "Capgemini India!!";
  message:string;
  myParrentMethod(msg:string) {
      this.message = msg;
  }
}
