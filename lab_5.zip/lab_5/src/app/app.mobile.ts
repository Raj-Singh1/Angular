
export class Mobile {
    mobId:number;
    mobName:string;
    mobPrice:number;
    mobBrand:string;
}