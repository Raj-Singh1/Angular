import { Component, OnInit } from "@angular/core";
import { MobileService } from "./appcomponentservice";
import { Mobile } from "./app.mobile";


@Component(
    {
        selector: "mob-show",
        templateUrl: "./app.showmobiles.html"
        
    }
)
export class ShowMobileComponent implements OnInit {

    empArr:Mobile[];
    flag=1;
    constructor(private mobileservice: MobileService){}

    ngOnInit(): void {
       this.empArr = this.mobileservice.showAllData();
    }

    delete(deleteId){
        this.empArr = this.mobileservice.delete(deleteId);

    }

}