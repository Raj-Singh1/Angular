import { Component, OnInit } from '@angular/core';
import { Hello } from '../hello';

@Component({
  selector: 'app-appli',
  templateUrl: './appli.component.html',
  styleUrls: ['./appli.component.css']
})
export class AppliComponent implements OnInit {
  ap:Hello=new Hello();
  ap1:Hello=new Hello();
  constructor() { }
  ngOnInit() {
  }

 /* alertBox(){
    alert(this.ap.id+" "+this.ap.name+" "+this.ap.sal+" "+this.ap.dept)
  }*/
  addEmp(){
      this.appli.push(this.ap);
  }

  appli:Hello[]=[
    {id:1001,name:"teju",sal:20000,dept:"cse"},
    {id:1002,name:"teju",sal:40000,dept:"cse"},
    {id:1003,name:"teju",sal:30000,dept:"cse"},
    {id:1004,name:"teju",sal:25000,dept:"cse"},
  ]

  update(e:Hello){
    Object.assign(this.ap1,e)
  }
  delete(id:number){
    this.appli=this.appli.filter(x=>x.id!=id)
  }
  update1(e1:Hello){
    this.delete(e1.id);
    this.appli.push(e1)
  }
}
