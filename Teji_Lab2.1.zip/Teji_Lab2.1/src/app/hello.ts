export class Hello {
    id:number;
    name:string;
    sal:number;
    dept:string;
}
