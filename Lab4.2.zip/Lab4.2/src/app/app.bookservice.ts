import {Injectable} from '@angular/core';
//import { HttpClient } from '../../node_modules/@types/selenium-webdriver/http';
import { HttpClient } from '@angular/common/http';
@Injectable()


export class BookService{
    constructor(private http:HttpClient){

    }

    getAllProduct():any{
        return this.http.get("assets/booklist.json");
    }
}