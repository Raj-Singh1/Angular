import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'filterse'
})
export class FilterPipe implements PipeTransform {
    searchText='';
    transform(items: any, searchText: any, ele:any) {
        
        if(!items) return [];
        if(!searchText) return items;
        searchText=searchText.toLowerCase();
        ele=ele.toLowerCase();
        switch(ele){
        case 'id':{
        return items.filter(items=>{
            return items.id.toString().includes(searchText);
        })
    }
        case 'title':{
        return items.filter(items=>{
            return items.title.toLowerCase().includes(searchText);
        })
    }
        
        case 'year':{
        return items.filter(items=>{
            return items.year.toString().toLowerCase().includes(searchText);
        })
    }

        case 'author':{
        return items.filter(items=>{
            return items.author.toLowerCase().includes(searchText);
        })
    }
    }
    }
}

