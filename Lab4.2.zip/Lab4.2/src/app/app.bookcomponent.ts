import {Book} from './book';
import {Component, OnInit} from '@angular/core';
import { BookService } from './app.bookservice';

@Component({
    selector:'app-prod',
    templateUrl:'./app.book.html',
    providers:[BookService]
})
export class BookComponent implements OnInit{
    books:Book[];
    constructor(private iteration:BookService){

    }
    ngOnInit(){
        this.iteration.getAllProduct().subscribe((data:Book[])=>this.books=data)
    }
}