import { Component, Pipe } from '@angular/core';
//import {FilterPipe} from './filter.pipes';


@Component({
  selector: 'app-root',
  templateUrl:'./app.component.html',
  
})
export class AppComponent {
  title = 'My First Angular5.....';
  mydata:string="Welcome to Capgemini...";



}