import { Employee } from "./employee";
import {Component} from "@angular/core";
@Component({
    selector:'emp-app',
    templateUrl:'./employee.html'
})

export class EmployeeComponent extends Employee  {


    model1:any={};

    model:any={};
    arr:Employee[]=[
        {empId:1001,empName:'Rahul',empSal:9000,empDep:'JAVA'},
        {empId:1002,empName:'Vikash',empSal:11000,empDep:'ORAAPS'},
         {empId:1005,empName:'Amol',empSal:7000,empDep:'.NET'},
         {empId:1006,empName:'Vishal',empSal:17000,empDep:'BI'},
         {empId:1003,empName:'Uma',empSal:12000,empDep:'JAVA'},
         {empId:1004,empName:'Sachin',empSal:11500,empDep:'ORAAPS'}
   
    ];
    Add():any{
        this.arr.push(this.model);
        this.model={};

    }
    Delete(i):any{
alert(i);
this.arr.splice(i,1);
    }

    update(i):any{
        alert(i);
        this.model1=this.arr[i];
    }
    Updated(){
        this.model1.empId=(document.getElementById("a") as HTMLInputElement).value;
        this.model1.empName=(document.getElementById("b") as HTMLInputElement).value;
        this.model1.empSal=(document.getElementById("c") as HTMLInputElement).value;
        this.model1.empDep=(document.getElementById("d") as HTMLInputElement).value;
        this.model1={};
    }
    sortId():any{this.arr.sort(function abc(a,b)
    {
        return a.empId-b.empId;
    }
    )};
    sortName():any{
        this.arr.sort(function abc(a,b){
            if(a.empName > b.empName){
                return 1;
            }
         if(a.empName < b.empName){
                return -1;
            }
            return 0;
        });
    }
    sortSal():any{this.arr.sort(function abc(a,b)
        {
            return a.empSal-b.empSal;
        }
        )};
        sortDep():any{
            this.arr.sort(function abc(a,b){
                if(a.empDep > b.empDep){
                    return 1;
                }
             if(a.empDep < b.empDep){
                    return -1;
                }
                return 0;
            });
        }
}